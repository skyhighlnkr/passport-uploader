<?php
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class Submissions_List_Table extends WP_List_Table {

    private $decrypted_data_cache = [];

    public function __construct() {
        parent::__construct([
            'singular' => __('Submission', 'islandtime-passport'),
            'plural'   => __('Submissions', 'islandtime-passport'),
            'ajax'     => false
        ]);
    }

    private function decrypt_data($data, $field_name = '') {
        if (empty($data)) {
            return $data;
        }
        
        if (!defined('PASSPORT_ENCRYPTION_KEY')) {
            return '[ENCRYPTION KEY MISSING]';
        }

        $key = base64_decode(PASSPORT_ENCRYPTION_KEY);
        if (strlen($key) !== 32) {
             return '[INVALID KEY LENGTH]';
        }
        
        $cipher = "AES-256-CBC";
        $iv_length = openssl_cipher_iv_length($cipher);
        
        try {
            $decoded_data = base64_decode($data, true);
            if ($decoded_data === false) {
                return '[BASE64 DECODE FAILED]';
            }
            
            if (strlen($decoded_data) < $iv_length) {
                return '[DATA TOO SHORT]';
            }
            
            $iv = substr($decoded_data, 0, $iv_length);
            $encrypted = substr($decoded_data, $iv_length);
            
            $decrypted = openssl_decrypt($encrypted, $cipher, $key, 0, $iv);
            
            if ($decrypted === false) {
                return '[DECRYPTION FAILED]';
            }
            
            return $decrypted;
            
        } catch (Exception $e) {
            return '[EXCEPTION: ' . $e->getMessage() . ']';
        }
    }

    public function get_columns() {
        $columns = [
            'cb'        => '<input type="checkbox" />',
            'id'        => __('ID', 'islandtime-passport'),
            'user_name' => __('Person Who Booked', 'islandtime-passport'),
            'user_email'=> __('Email', 'islandtime-passport'),
            'user_phone'=> __('Phone', 'islandtime-passport'),
            'submission_date' => __('Travel Date', 'islandtime-passport'),
            'file_path' => __('Passport Files', 'islandtime-passport'),
            'submission_time' => __('Submitted On', 'islandtime-passport'),
        ];
        return $columns;
    }

    protected function get_sortable_columns() {
        $sortable_columns = [
            'id' => ['id', true],
            'user_name' => ['user_name', false],
            'submission_time' => ['submission_time', true],
            'submission_date' => ['submission_date', false],
        ];
        return $sortable_columns;
    }

    public function prepare_items() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'passport_submissions';
        $per_page = 20;
        $current_page = $this->get_pagenum();
        
        $all_data = $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A);
        
        $processed_data = [];
        if (!empty($all_data)) {
            foreach ($all_data as $item) {
                $item['_decrypted_name'] = $this->decrypt_data($item['user_name'], 'user_name');
                $item['_decrypted_email'] = $this->decrypt_data($item['user_email'], 'user_email');
                $item['_decrypted_phone'] = $this->decrypt_data($item['user_phone'], 'user_phone');
                
                $this->decrypted_data_cache[$item['id']] = [
                    'user_name' => $item['_decrypted_name'],
                    'user_email' => $item['_decrypted_email'],
                    'user_phone' => $item['_decrypted_phone']
                ];

                $processed_data[] = $item;
            }
        }
        
        $search = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';
        if (!empty($search)) {
            $filtered_data = [];
            foreach ($processed_data as $item) {
                if (stripos($item['_decrypted_name'], $search) !== false || stripos($item['_decrypted_email'], $search) !== false) {
                    $filtered_data[] = $item;
                }
            }
        } else {
            $filtered_data = $processed_data;
        }

        $orderby = isset($_GET['orderby']) ? sanitize_sql_orderby($_GET['orderby']) : 'submission_time';
        $order = isset($_GET['order']) && in_array(strtoupper($_GET['order']), ['ASC', 'DESC']) ? strtoupper($_GET['order']) : 'DESC';

        usort($filtered_data, function($a, $b) use ($orderby, $order) {
            $a_val = '';
            $b_val = '';

            switch ($orderby) {
                case 'user_name':
                    $a_val = $a['_decrypted_name'];
                    $b_val = $b['_decrypted_name'];
                    break;
                case 'id':
                    $a_val = (int)$a['id'];
                    $b_val = (int)$b['id'];
                    break;
                case 'submission_date':
                    $a_val = $a['submission_date'];
                    $b_val = $b['submission_date'];
                    break;
                case 'submission_time':
                default:
                    $a_val = $a['submission_time'];
                    $b_val = $b['submission_time'];
                    break;
            }

            $result = 0;
            if (is_numeric($a_val) && is_numeric($b_val)) {
                $result = $a_val - $b_val;
            } else {
                $result = strcmp((string)$a_val, (string)$b_val);
            }
            
            return ($order === 'ASC') ? $result : -$result;
        });

        $total_items = count($filtered_data);
        $this->items = array_slice($filtered_data, ($current_page - 1) * $per_page, $per_page);

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);
        
        $this->_column_headers = array($this->get_columns(), array(), $this->get_sortable_columns());
    }

    public function column_default($item, $column_name) {
        switch($column_name) {
            case 'id':
                return esc_html($item['id']);
            case 'submission_date':
                return esc_html(date_i18n(get_option('date_format'), strtotime($item['submission_date'])));
            case 'submission_time':
                return $this->column_submission_time($item);
            case 'file_path':
                return $this->column_file_path($item);
            case 'user_name':
                $name = $this->decrypted_data_cache[$item['id']]['user_name'] ?? '[Error]';
                return esc_html($name);
            case 'user_email':
                $email = $this->decrypted_data_cache[$item['id']]['user_email'] ?? '[Error]';
                return esc_html($email);
            case 'user_phone':
                $phone = $this->decrypted_data_cache[$item['id']]['user_phone'] ?? '[Error]';
                return esc_html($phone);
            default:
                return esc_html(print_r($item, true));
        }
    }

    public function column_file_path($item) {
        $file_path_json = $item['file_path'];
        if (empty($file_path_json)) {
            return __('No files', 'islandtime-passport');
        }

        $filenames = json_decode($file_path_json, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($filenames)) {
            $filenames = [$file_path_json];
        }

        $download_links = [];
        foreach ($filenames as $index => $filename) {
            $safe_filename = basename($filename);
            
            $nonce = wp_create_nonce('download_passport_' . $item['id'] . '_file_' . $index);
            
            $download_url = admin_url('admin.php?page=passport-submissions&download_submission_id=' . $item['id'] . '&file_index=' . $index . '&_wpnonce=' . $nonce);
            
            $file_extension = strtolower(pathinfo($safe_filename, PATHINFO_EXTENSION));
            $icon = '';
            switch ($file_extension) {
                case 'pdf':
                    $icon = '📄';
                    break;
                case 'jpg':
                case 'jpeg':
                case 'png':
                    $icon = '🖼️';
                    break;
                default:
                    $icon = '📎';
            }
            
            $download_links[] = '<a href="' . esc_url($download_url) . '" class="download-link" target="_blank">' 
                              . $icon . ' ' . sprintf(__('File %d', 'islandtime-passport'), $index + 1) 
                              . '</a>';
        }

        return '<div class="file-download-links">' . implode('<br>', $download_links) . '</div>';
    }

    public function column_submission_time($item) {
        $date_display = esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($item['submission_time'])));
        
        $actions = [];
        
        $download_url = wp_nonce_url(
            admin_url('admin.php?page=passport-submissions&download_submission_id=' . $item['id']),
            'download_submission_' . $item['id']
        );
        $actions['download'] = sprintf(
            '<a href="%s">%s</a>',
            $download_url,
            __('Download Files', 'islandtime-passport')
        );
        
        // FIXED: Use the correct URL structure and nonce for individual deletion
        $delete_url = wp_nonce_url(
            admin_url('admin.php?page=passport-submissions&action=delete_submission&submission_id=' . $item['id']),
            'delete_submission_' . $item['id']  // Individual nonce per submission
        );
        $actions['delete'] = sprintf(
            '<a href="%s" onclick="return confirm(\'%s\')" style="color:#a00;">%s</a>',
            $delete_url,
            esc_js(__('Are you sure you want to delete this submission? This action cannot be undone.', 'islandtime-passport')),
            __('Delete', 'islandtime-passport')
        );
        
        return $date_display . $this->row_actions($actions);
    }

    public function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="submission_ids[]" value="%s" />',
            $item['id']
        );
    }

    public function get_bulk_actions() {
        $actions = [
            'delete' => __('Delete', 'islandtime-passport')
        ];
        return $actions;
    }

    public function process_bulk_action() {
        // Let the main plugin class handle bulk deletions
        // This method should only handle the action detection for the list table
        // The actual deletion processing happens in the main plugin class
        
        if ($this->current_action() === 'delete' && isset($_POST['submission_ids'])) {
            // The main plugin class will handle the actual deletion via admin_init
            // We just need to return and let it process
            return;
        }
    }
}
?>