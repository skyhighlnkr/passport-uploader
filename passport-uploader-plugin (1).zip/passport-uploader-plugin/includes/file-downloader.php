<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this file.', 'islandtime-passport'));
}

$submission_id = isset($_GET['download_submission_id']) ? intval($_GET['download_submission_id']) : 0;
$file_index = isset($_GET['file_index']) ? intval($_GET['file_index']) : 0;

if ($submission_id === 0) {
    wp_die(__('Invalid submission ID.', 'islandtime-passport'));
}

$nonce = isset($_GET['_wpnonce']) ? $_GET['_wpnonce'] : '';

$nonce_action_individual = 'download_passport_' . $submission_id . '_file_' . $file_index;
$nonce_action_bulk = 'download_submission_' . $submission_id;

if (!wp_verify_nonce($nonce, $nonce_action_individual) && !wp_verify_nonce($nonce, $nonce_action_bulk)) {
    wp_die(__('Security check failed. Please try again.', 'islandtime-passport'));
}

global $wpdb;
$table_name = $wpdb->prefix . 'passport_submissions';

$submission = $wpdb->get_row($wpdb->prepare(
    "SELECT file_path FROM $table_name WHERE id = %d",
    $submission_id
), ARRAY_A);

if (!$submission) {
    wp_die(__('Submission not found.', 'islandtime-passport'));
}

$file_path_json = $submission['file_path'];
if (empty($file_path_json)) {
    wp_die(__('No file data found for this submission.', 'islandtime-passport'));
}

$filenames = json_decode($file_path_json, true);

if (json_last_error() !== JSON_ERROR_NONE || !is_array($filenames)) {
    $filenames = [$file_path_json];
}

if ($file_index > 0) {
    if (!isset($filenames[$file_index])) {
        wp_die(__('File index is invalid.', 'islandtime-passport'));
    }
    $filename = $filenames[$file_index];
    $download_all = false;
} else {
    $download_all = true;
    
    if (empty($filenames)) {
        wp_die(__('No files found for this submission.', 'islandtime-passport'));
    }
}

if ($download_all) {
    $zip = new ZipArchive();
    $zip_filename = 'passport-submission-' . $submission_id . '.zip';
    $zip_filepath = PASSPORT_UPLOADER_UPLOAD_DIR . $zip_filename;
    
    if ($zip->open($zip_filepath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        $files_added = 0;
        
        foreach ($filenames as $index => $filename) {
            $safe_filename = basename($filename);
            $full_filepath = PASSPORT_UPLOADER_UPLOAD_DIR . $safe_filename;
            
            if (file_exists($full_filepath) && is_readable($full_filepath)) {
                $zip->addFile($full_filepath, ($index + 1) . '_' . $safe_filename);
                $files_added++;
            }
        }
        
        $zip->close();
        
        if ($files_added === 0) {
            @unlink($zip_filepath);
            wp_die(__('No readable files found to download.', 'islandtime-passport'));
        }
        
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
        header('Content-Length: ' . filesize($zip_filepath));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        readfile($zip_filepath);
        
        @unlink($zip_filepath);
        exit;
        
    } else {
        wp_die(__('Failed to create ZIP archive.', 'islandtime-passport'));
    }
    
} else {
    $safe_filename = basename($filename);
    $full_filepath = PASSPORT_UPLOADER_UPLOAD_DIR . $safe_filename;

    if (!file_exists($full_filepath) || !is_readable($full_filepath)) {
        wp_die(__('File not found on server or is not readable.', 'islandtime-passport'));
    }

    $filetype = wp_check_filetype($safe_filename);
    $mime_type = $filetype['type'] ?? 'application/octet-stream';

    if (ob_get_level()) {
        ob_end_clean();
    }

    header('Content-Type: ' . $mime_type);
    header('Content-Disposition: inline; filename="' . $safe_filename . '"');
    header('Content-Length: ' . filesize($full_filepath));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    readfile($full_filepath);
    exit;
}
?>