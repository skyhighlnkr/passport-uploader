<?php
/**
 * Plugin Name: Passport Uploader for Island Time BVI
 * Description: Secure PII document ingestion and passport upload architecture for Island Time BVI guest charters.
 * Version: 1.1.7
 * Author: Jason Itumay / iWebhacks
 * Author URI: https://iwebhacks.com/
 *
 * Original custom software architecture and development:
 * Jason Itumay / iWebhacks
 *
 * Copyright (c) 2026 Jason Itumay / iWebhacks.
 * All rights reserved except where otherwise agreed in writing.
 *
 * This software was custom-developed for the Island Time BVI document management workflow.
 * Removal or modification of this attribution does not alter the original
 * authorship or development history of the software.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PASSPORT_UPLOADER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PASSPORT_UPLOADER_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('PASSPORT_UPLOADER_UPLOAD_DIR', WP_CONTENT_DIR . '/uploads/private_passports/');

/**
 * Main Plugin Class
 */
class PassportUploaderPlugin {

    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_post_handle_passport_submission', array($this, 'handle_form_submission'));
        add_action('admin_post_nopriv_handle_passport_submission', array($this, 'handle_form_submission'));
        add_shortcode('passport_submission_form', array($this, 'render_shortcode_form'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('elementor/frontend/after_enqueue_scripts', array($this, 'force_load_elementor_assets'));
        
        // Add AJAX handler for nonce - FOR HTML WIDGET SUPPORT
        add_action('wp_ajax_get_passport_nonce', array($this, 'get_passport_nonce'));
        add_action('wp_ajax_nopriv_get_passport_nonce', array($this, 'get_passport_nonce'));

        // Add anti-follow-up features
        add_filter('wp_mail', array($this, 'block_auto_replies'), 1, 1);
        add_shortcode('passport_status', array($this, 'passport_status_shortcode'));
    }

    /**
     * AJAX handler to get nonce for HTML widget forms
     */
    public function get_passport_nonce() {
        wp_send_json_success(array(
            'nonce' => wp_create_nonce('passport_upload_nonce')
        ));
    }

    /**
     * Encrypt data before storing in database
     */
    private function encrypt_data($data) {
        if (empty($data)) return $data;
        
        // 1. Get the decoded key
        if (!defined('PASSPORT_ENCRYPTION_KEY')) {
            error_log("PASSPORT_ENCRYPTION_KEY is not defined");
            return false; // Fail if key is missing
        }
        $key = base64_decode(PASSPORT_ENCRYPTION_KEY);
        
        // 2. Check key length
        if (strlen($key) !== 32) {
            error_log("DEBUG: INVALID KEY. Key must be 32 bytes after base64_decode. Got: " . strlen($key));
            return false; // Fail if key is wrong length
        }
        
        $cipher = "AES-256-CBC";
        $iv_length = openssl_cipher_iv_length($cipher);
        $iv = openssl_random_pseudo_bytes($iv_length);
        
        // Use the DECODED $key variable here
        $encrypted = openssl_encrypt($data, $cipher, $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }

    /**
     * Decrypt data from database
     */
    private function decrypt_data($data) {
        if (empty($data)) return $data;

        // 1. Get the decoded key
        if (!defined('PASSPORT_ENCRYPTION_KEY')) {
            error_log("PASSPORT_ENCRYPTION_KEY is not defined");
            return false; // Fail if key is missing
        }
        $key = base64_decode(PASSPORT_ENCRYPTION_KEY);

        // 2. Check key length
        if (strlen($key) !== 32) {
            error_log("DEBUG: INVALID KEY. Key must be 32 bytes after base64_decode. Got: " . strlen($key));
            return false; // Fail if key is wrong length
        }
        
        $cipher = "AES-256-CBC";
        $iv_length = openssl_cipher_iv_length($cipher);
        
        $data = base64_decode($data);
        if ($data === false || strlen($data) < $iv_length) {
            error_log("DEBUG: Decrypt failed, data invalid.");
            return false;
        }

        $iv = substr($data, 0, $iv_length);
        $encrypted = substr($data, $iv_length);
        
        // Use the DECODED $key variable here
        return openssl_decrypt($encrypted, $cipher, $key, 0, $iv);
    }

    /**
     * Plugin Activation: Create DB Table and Secure Directory.
     */
    public function activate() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'passport_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_name TEXT NOT NULL,
            user_email TEXT NOT NULL,
            user_phone TEXT,
            submission_date date,
            file_path TEXT NOT NULL,
            submission_time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Create the secure upload directory
        if (!file_exists(PASSPORT_UPLOADER_UPLOAD_DIR)) {
            wp_mkdir_p(PASSPORT_UPLOADER_UPLOAD_DIR);
        }

        // Add .htaccess to block direct access
        $htaccess_file = PASSPORT_UPLOADER_UPLOAD_DIR . '.htaccess';
        if (!file_exists($htaccess_file)) {
            file_put_contents($htaccess_file, 'Deny from all');
        }
    }

/**
 * Initialize the plugin - FIXED BULK DELETION VERSION
 */
public function init() {
    error_log('DEBUG: init() called');

    // Load the file downloader if the correct parameters are present
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'passport-submissions' && isset($_GET['download_submission_id'])) {
        error_log('DEBUG: File downloader triggered');
        $downloader_path = PASSPORT_UPLOADER_PLUGIN_PATH . 'includes/file-downloader.php';
        if (file_exists($downloader_path)) {
            require_once $downloader_path;
        } else {
            wp_die('Error: File downloader is missing.');
        }
        exit;
    }
    
    // Handle single deletion
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'passport-submissions') {
        if (isset($_GET['action']) && $_GET['action'] === 'delete_submission' && isset($_GET['submission_id'])) {
            error_log('DEBUG: Single deletion triggered via delete_submission');
            $this->handle_submission_deletion();
        }
        // Also handle the old 'delete' action for backward compatibility
        elseif (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['submission_id'])) {
            error_log('DEBUG: Single deletion triggered via delete (legacy)');
            $this->handle_submission_deletion();
        }
    }
    
    // Handle bulk deletion - FIXED: Check for both POST and GET requests
    // WordPress bulk actions can come via POST (form submission) or GET (URL parameters)
    if (is_admin() && isset($_REQUEST['page']) && $_REQUEST['page'] === 'passport-submissions') {
        // Check for bulk action in POST (form submission)
        if (isset($_POST['action']) && $_POST['action'] === '-1') {
            // WordPress uses '-1' as value when no bulk action is selected, so check action2
            if (isset($_POST['action2']) && $_POST['action2'] === 'delete') {
                error_log('DEBUG: Bulk deletion triggered via POST action2');
                $this->handle_bulk_deletion();
            }
        }
        // Check for bulk action in POST with actual action value
        elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
            error_log('DEBUG: Bulk deletion triggered via POST action');
            $this->handle_bulk_deletion();
        }
        // Check for bulk action in GET (URL parameters)
        elseif (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['submission_ids'])) {
            error_log('DEBUG: Bulk deletion triggered via GET');
            $this->handle_bulk_deletion();
        }
    }
}

   /**
 * Handle submission deletion - FIXED VERSION
 */
public function handle_submission_deletion() {
    error_log('DEBUG: handle_submission_deletion() STARTED');
    
    // Check permissions
    if (!current_user_can('edit_pages')) {
        error_log('DEBUG: Permission check failed');
        wp_die(__('You do not have sufficient permissions to perform this action.', 'islandtime-passport'));
    }

    // Check if we have the required parameters
    if (!isset($_GET['submission_id']) || !isset($_GET['_wpnonce'])) {
        error_log('DEBUG: Missing submission_id or _wpnonce');
        wp_die(__('Invalid request parameters.', 'islandtime-passport'));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'passport_submissions';
    $submission_id = intval($_GET['submission_id']);

    error_log('DEBUG: Attempting to delete submission ID: ' . $submission_id);

    // Verify nonce - FIXED: Use the correct nonce action for single deletion
    $nonce_actions = array(
        'bulk-submissions', // For bulk actions
        'delete_submission_' . $submission_id, // Correct format for single deletion
        'delete_submission' // Your original attempt
    );
    
    $nonce_valid = false;
    foreach ($nonce_actions as $action) {
        if (wp_verify_nonce($_GET['_wpnonce'], $action)) {
            $nonce_valid = true;
            error_log('DEBUG: Nonce valid with action: ' . $action);
            break;
        }
    }

    if (!$nonce_valid) {
        error_log('DEBUG: All nonce checks failed. Nonce value: ' . $_GET['_wpnonce']);
        wp_die(__('Security verification failed.', 'islandtime-passport'));
    }

    // Get the submission data first to delete files
    $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $submission_id));
    
    if ($submission) {
        error_log('DEBUG: Submission found in database');
        // Delete associated files
        $file_paths = json_decode($submission->file_path, true);
        if (is_array($file_paths)) {
            error_log('DEBUG: Found ' . count($file_paths) . ' files to delete');
            foreach ($file_paths as $filename) {
                $file_path = PASSPORT_UPLOADER_UPLOAD_DIR . $filename;
                if (file_exists($file_path)) {
                    $deleted = @unlink($file_path);
                    error_log('DEBUG: File ' . $filename . ' deletion: ' . ($deleted ? 'SUCCESS' : 'FAILED'));
                } else {
                    error_log('DEBUG: File not found: ' . $file_path);
                }
            }
        }

        // Delete database record
        $result = $wpdb->delete($table_name, array('id' => $submission_id), array('%d'));
        error_log('DEBUG: Database deletion result: ' . ($result ? 'SUCCESS' : 'FAILED'));

        if ($result) {
            error_log('DEBUG: Database record deleted successfully');
            $redirect_url = admin_url('admin.php?page=passport-submissions&deleted=1');
        } else {
            error_log('DEBUG: Failed to delete database record');
            $redirect_url = admin_url('admin.php?page=passport-submissions&deleted=0');
        }
    } else {
        error_log('DEBUG: Submission not found in database');
        $redirect_url = admin_url('admin.php?page=passport-submissions&deleted=0');
    }

    error_log('DEBUG: Redirecting to: ' . $redirect_url);
    wp_safe_redirect($redirect_url);
    exit;
}
    /**
 * Handle bulk deletion - FIXED VERSION
 */
public function handle_bulk_deletion() {
    error_log('DEBUG: handle_bulk_deletion() STARTED');
    
    // Check permissions
    if (!current_user_can('edit_pages')) {
        error_log('DEBUG: Permission check failed');
        wp_die(__('You do not have sufficient permissions to perform this action.', 'islandtime-passport'));
    }

    // Verify nonce - FIXED: Check for both POST and GET nonce
    $nonce_valid = false;
    if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'bulk-submissions')) {
        $nonce_valid = true;
        error_log('DEBUG: POST nonce valid');
    } elseif (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'bulk-submissions')) {
        $nonce_valid = true;
        error_log('DEBUG: GET nonce valid');
    }

    if (!$nonce_valid) {
        error_log('DEBUG: Nonce verification failed');
        wp_die(__('Security verification failed.', 'islandtime-passport'));
    }

    // Get submission IDs from either POST or GET
    $submission_ids = array();
    
    if (isset($_POST['submission_ids']) && is_array($_POST['submission_ids'])) {
        $submission_ids = $_POST['submission_ids'];
        error_log('DEBUG: Got submission IDs from POST: ' . implode(', ', $submission_ids));
    } elseif (isset($_GET['submission_ids']) && is_array($_GET['submission_ids'])) {
        $submission_ids = $_GET['submission_ids'];
        error_log('DEBUG: Got submission IDs from GET: ' . implode(', ', $submission_ids));
    }

    if (empty($submission_ids)) {
        error_log('DEBUG: No submission IDs provided');
        wp_safe_redirect(admin_url('admin.php?page=passport-submissions&bulk_deleted=0'));
        exit;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'passport_submissions';
    $deleted_count = 0;

    foreach ($submission_ids as $submission_id) {
        $submission_id = intval($submission_id);
        error_log('DEBUG: Processing deletion for submission ID: ' . $submission_id);
        
        // Get the submission data first to delete files
        $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $submission_id));
        
        if ($submission) {
            error_log('DEBUG: Submission found in database');
            // Delete associated files
            $file_paths = json_decode($submission->file_path, true);
            if (is_array($file_paths)) {
                error_log('DEBUG: Found ' . count($file_paths) . ' files to delete');
                foreach ($file_paths as $filename) {
                    $file_path = PASSPORT_UPLOADER_UPLOAD_DIR . $filename;
                    if (file_exists($file_path)) {
                        $deleted = @unlink($file_path);
                        error_log('DEBUG: File ' . $filename . ' deletion: ' . ($deleted ? 'SUCCESS' : 'FAILED'));
                    } else {
                        error_log('DEBUG: File not found: ' . $file_path);
                    }
                }
            }

            // Delete database record
            $result = $wpdb->delete($table_name, array('id' => $submission_id), array('%d'));
            error_log('DEBUG: Database deletion result: ' . ($result ? 'SUCCESS' : 'FAILED'));

            if ($result) {
                $deleted_count++;
                error_log('DEBUG: Successfully deleted submission ID: ' . $submission_id);
            }
        } else {
            error_log('DEBUG: Submission not found in database for ID: ' . $submission_id);
        }
    }

    error_log('DEBUG: Total submissions deleted: ' . $deleted_count);
    $redirect_url = admin_url('admin.php?page=passport-submissions&bulk_deleted=' . $deleted_count);
    error_log('DEBUG: Redirecting to: ' . $redirect_url);
    wp_safe_redirect($redirect_url);
    exit;
}

    /**
     * Enqueue admin styles
     */
    public function enqueue_admin_styles($hook) {
        // Only load on our admin page
        if ($hook !== 'toplevel_page_passport-submissions') {
            return;
        }
        
        wp_enqueue_style(
            'passport-uploader-admin',
            PASSPORT_UPLOADER_PLUGIN_URL . 'assets/admin-style.css',
            array(),
            '1.1.6'
        );
        
        // Also load the frontend script for bulk deletion functionality
        wp_enqueue_script(
            'passport-uploader-frontend',
            PASSPORT_UPLOADER_PLUGIN_URL . 'assets/frontend-script.js',
            array('jquery'),
            '1.1.6',
            true
        );
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        // Load on all frontend pages to ensure Elementor compatibility
        wp_enqueue_style(
            'passport-uploader-frontend',
            PASSPORT_UPLOADER_PLUGIN_URL . 'assets/frontend-style.css',
            array(),
            '1.1.6'
        );
        
        wp_enqueue_script(
            'passport-uploader-frontend',
            PASSPORT_UPLOADER_PLUGIN_URL . 'assets/frontend-script.js',
            array('jquery'),
            '1.1.6',
            true
        );
        
        // Localize script for AJAX - UPDATED with HEIC support
        wp_localize_script('passport-uploader-frontend', 'passport_uploader', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'max_files' => 20,
            'max_size' => 50 * 1024 * 1024,
            'allowed_types' => __('JPG, PNG, PDF, HEIC files only', 'islandtime-passport')
        ));
    }

    /**
     * Force load assets for Elementor compatibility
     */
    public function force_load_elementor_assets() {
        // Always load our assets when Elementor is detected
        if (defined('ELEMENTOR_VERSION')) {
            $this->enqueue_frontend_scripts();
        }
    }

    /**
     * Create the Admin Menu Page - SIMPLE APPROACH using edit_pages capability
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Passport Submissions', 'islandtime-passport'),
            __('Passport Submissions', 'islandtime-passport'),
            'edit_pages', // Editors and Administrators can access
            'passport-submissions',
            array($this, 'render_admin_page'),
            'dashicons-portfolio',
            30
        );
    }

    /**
 * Render the Admin Page using WP_List_Table with enhanced UI
 */
public function render_admin_page() {
    // Check if user can edit pages (editors and administrators)
    if (!current_user_can('edit_pages')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'islandtime-passport'));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'passport_submissions';
    
    // Get some basic stats
    $total_submissions = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $today_submissions = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE DATE(submission_time) = %s",
        current_time('Y-m-d')
    ));

    echo '<div class="wrap passport-submissions-wrap">';
    echo '<h1>' . __('Passport Submissions', 'islandtime-passport') . '</h1>';
    
    // Display stats boxes
    echo '<div class="passport-header-stats">';
    echo '<div class="passport-stat-box">';
    echo '<span class="passport-stat-number">' . esc_html($total_submissions) . '</span>';
    echo '<span class="passport-stat-label">' . __('Total Submissions', 'islandtime-passport') . '</span>';
    echo '</div>';
    echo '<div class="passport-stat-box">';
    echo '<span class="passport-stat-number">' . esc_html($today_submissions) . '</span>';
    echo '<span class="passport-stat-label">' . __('Today\'s Submissions', 'islandtime-passport') . '</span>';
    echo '</div>';
    echo '</div>';

    // Security reminder
    echo '<div class="passport-alert warning">';
    echo '<strong>' . __('Security Notice:', 'islandtime-passport') . '</strong> ';
    echo __('You are viewing sensitive passport information. Ensure you follow proper data handling procedures.', 'islandtime-passport');
    echo '</div>';
    
    // Check for encryption key
    if (!defined('PASSPORT_ENCRYPTION_KEY')) {
         echo '<div class="passport-alert error" style="background: #f8d7da; color: #721c24; border-left-color: #f5c6cb;">';
         echo '<strong>' . __('CRITICAL ERROR:', 'islandtime-passport') . '</strong> ';
         echo __('The <code>PASSPORT_ENCRYPTION_KEY</code> is not defined in your <code>wp-config.php</code> file. Submissions cannot be encrypted or decrypted.', 'islandtime-passport');
         echo '</div>';
    }

    // Include and display the custom list table
    $list_table_path = PASSPORT_UPLOADER_PLUGIN_PATH . 'includes/class-submissions-list-table.php';
    if (file_exists($list_table_path)) {
        require_once $list_table_path;
    } else {
         echo '<div class="passport-alert error" style="background: #f8d7da; color: #721c24; border-left-color: #f5c6cb;">';
         echo '<strong>' . __('CRITICAL ERROR:', 'islandtime-passport') . '</strong> ';
         echo __('The file <code>includes/class-submissions-list-table.php</code> is missing.', 'islandtime-passport');
         echo '</div>';
         echo '</div>'; // close .wrap
         return; // Stop rendering
    }

    $submissions_table = new Submissions_List_Table();
    
    // Process bulk actions FIRST
    $submissions_table->process_bulk_action();
    
    // Then prepare items
    $submissions_table->prepare_items();
    
    // Display admin notices
    if (isset($_GET['deleted'])) {
        if ($_GET['deleted'] === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Submission deleted successfully.', 'islandtime-passport') . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . __('Failed to delete submission.', 'islandtime-passport') . '</p></div>';
        }
    }

    if (isset($_GET['bulk_deleted'])) {
        $count = intval($_GET['bulk_deleted']);
        if ($count > 0) {
            echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(_n('%d submission deleted successfully.', '%d submissions deleted successfully.', $count, 'islandtime-passport'), $count) . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . __('No submissions were deleted.', 'islandtime-passport') . '</p></div>';
        }
    }

    // Add search box form
    echo '<form method="get">';
    echo '<input type="hidden" name="page" value="' . esc_attr($_REQUEST['page']) . '" />';
    $submissions_table->search_box(__('Search Submissions', 'islandtime-passport'), 'submission-search-input');
    echo '</form>';

    // Display the table (this will include the bulk actions dropdown)
    echo '<form method="post" id="passport-submissions-form">';
    // Add nonce for bulk actions
    wp_nonce_field('bulk-submissions', '_wpnonce');
    $submissions_table->display(); 
    echo '</form>';
    echo '</div>'; // close .wrap
}

    /**
     * Render the Front-End Form via Shortcode
     */
    public function render_shortcode_form() {
        ob_start();
        ?>
        <div class="passport-form-container">
            <div class="passport-form-header">
                <h1>Island Time BVI Passport Submission</h1>
                <p>Securely submit passport information for your water taxi adventure</p>
            </div>
            
            <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="passport-upload-form" id="passport-upload-form">
                <?php wp_nonce_field('passport_upload_nonce', 'passport_nonce_field'); ?>
                <input type="hidden" name="action" value="handle_passport_submission">

                <div class="form-section">
                    <h3>Reservation Information</h3>
                    
                    <div class="form-group">
                        <label for="user_name">Person Who Booked The Reservation *</label>
                        <input type="text" id="user_name" name="user_name" required 
                               placeholder="Enter the name of the person who made the booking"
                               autocomplete="name"
                               class="passport-form-field">
                    </div>

                    <div class="form-group">
                        <label for="user_email">Email Address *</label>
                        <input type="email" id="user_email" name="user_email" required 
                               placeholder="your@email.com"
                               autocomplete="email"
                               class="passport-form-field">
                    </div>

                    <div class="form-group">
                        <label for="user_phone">Phone Number</label>
                        <input type="tel" id="user_phone" name="user_phone" 
                               placeholder="+1 (555) 123-4567"
                               autocomplete="tel"
                               class="passport-form-field">
                    </div>

                    <div class="form-group">
                        <label for="travel_date">Travel Date *</label>
                        <input type="date" id="travel_date" name="travel_date" required 
                               min="<?php echo date('Y-m-d'); ?>"
                               class="passport-form-field">
                    </div>
                </div>

                <div class="form-section">
                    <h3>Passport Upload</h3>
                    <p class="form-description">Upload passport files for all guests in your reservation. You can upload multiple files.</p>
                    
                    <div class="file-upload-area" id="file-upload-area">
                        <div class="upload-instructions">
                            <span class="upload-icon">📄</span>
                            <h4>Upload Passport Files</h4>
                            <p>Click to browse or drag and drop files here</p>
                            <p class="file-requirements">JPG, PNG, PDF, HEIC files only • Max 50MB per file</p>
                        </div>
                        <input type="file" id="passport_files" name="passport_files[]" multiple accept=".jpg,.jpeg,.png,.pdf,.heic,.heif" style="display: none;">
                    </div>

                    <div class="file-preview-container" id="file-preview-container" style="display: none;">
                        <h4>Selected Files:</h4>
                        <div class="file-preview-list" id="file-preview-list"></div>
                        <button type="button" class="add-more-files-btn" id="add-more-files">
                            <span class="plus-icon">+</span>
                            Add More Files
                        </button>
                    </div>
                </div>

                <div class="form-submit">
                    <input type="submit" value="Submit Passport Information" id="submit-btn">
                    <div class="loading-spinner" id="loading-spinner" style="display: none;">
                        <div class="spinner"></div>
                        <span>Uploading files...</span>
                    </div>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Send email notifications to both info and watertaxi addresses
     */
    private function send_admin_email_notifications($user_name, $user_email, $user_phone, $travel_date, $file_count, $submission_id) {
        // Use BCC to send one email to both addresses instead of separate emails
        $to = 'info@islandtimeltd.com'; // Primary recipient
        $bcc = 'watertaxi@islandtimeltd.com'; // Secondary recipient (BCC)
        
        $site_name = get_bloginfo('name');
        $admin_page_link = admin_url('admin.php?page=passport-submissions');
        $submission_time = current_time('F j, Y g:i A');
        
        $subject = "New Passport Submission Received - {$user_name}";
        
        $message = "
NEW PASSPORT SUBMISSION - Island Time BVI
==========================================

A new passport submission has been received through the website.

SUBMISSION DETAILS:
-------------------
Booking Person: {$user_name}
Email Address: {$user_email}
Phone Number: " . ($user_phone ?: 'Not provided') . "
Travel Date: {$travel_date}
Number of Passport Files: {$file_count}
Submission ID: #{$submission_id}
Submitted On: {$submission_time}

VIEW SUBMISSION:
----------------
You can view this submission and download the passport files by visiting:
{$admin_page_link}

(Note: You must be logged into the Island Time BVI WordPress admin panel to access the dashboard.)

SECURITY REMINDER:
------------------
This submission contains sensitive passport information. Please ensure proper data handling procedures are followed when accessing and storing this information.

---
This email was automatically sent from {$site_name}
";
        
        $headers = array(
            'From: Island Time BVI <wordpress@' . parse_url(get_home_url(), PHP_URL_HOST) . '>',
            'Reply-To: ' . $user_name . ' <' . $user_email . '>',
            'Bcc: ' . $bcc, // Add watertaxi as BCC instead of separate email
            'Content-Type: text/plain; charset=UTF-8',
            'X-Passport-Submission-ID: ' . $submission_id
        );
        
        $result = wp_mail($to, $subject, $message, $headers);
        
        if ($result) {
            error_log("Passport Uploader: Admin notification email sent successfully to {$to} with BCC to {$bcc} for submission #{$submission_id}");
            return 1; // Return 1 since only one email is sent now
        } else {
            error_log("Passport Uploader: FAILED to send admin notification email for submission #{$submission_id}");
            return 0;
        }
    }

    /**
     * Handle form submission - FIXED VERSION
     */
    public function handle_form_submission() {
        // TEMPORARY DEBUG
        error_log('=== PASSPORT UPLOADER DEBUG ===');
        error_log('POST data: ' . print_r($_POST, true));
        error_log('FILES data: ' . print_r($_FILES, true));
        error_log('Nonce field: ' . ($_POST['passport_nonce_field'] ?? 'NOT SET'));
        error_log('Action: ' . ($_POST['action'] ?? 'NOT SET'));

        // 1. Verify Nonce - Try multiple methods for compatibility
        $nonce_valid = false;
        
        // Method 1: Standard nonce verification
        if (isset($_POST['passport_nonce_field']) && wp_verify_nonce($_POST['passport_nonce_field'], 'passport_upload_nonce')) {
            $nonce_valid = true;
        }
        // Method 2: Check for HTML widget simple nonce
        elseif (isset($_POST['passport_nonce_field']) && strpos($_POST['passport_nonce_field'], 'passport_nonce_') === 0) {
            $nonce_valid = true;
        }
        // Method 3: Allow form submission without nonce for testing (remove in production)
        elseif (defined('WP_DEBUG') && WP_DEBUG) {
            $nonce_valid = true;
            error_log('Passport Uploader: Nonce bypassed for debugging');
        }

        if (!$nonce_valid) {
            error_log('Passport Uploader: Security verification failed. Nonce: ' . ($_POST['passport_nonce_field'] ?? 'none'));
            wp_die(__('Security verification failed. Please try again.', 'islandtime-passport'));
        }

        global $wpdb;

        // 2. Sanitize Text Data - FIXED: Support all possible field names
        $user_name = '';
        $user_email = '';
        $user_phone = '';
        $travel_date = '';

        // Check for field names in order of priority
        if (isset($_POST['user_name']) && !empty($_POST['user_name'])) {
            $user_name = sanitize_text_field($_POST['user_name']);
        } elseif (isset($_POST['booking_person_name']) && !empty($_POST['booking_person_name'])) {
            $user_name = sanitize_text_field($_POST['booking_person_name']);
        }

        if (isset($_POST['user_email']) && !empty($_POST['user_email'])) {
            $user_email = sanitize_email($_POST['user_email']);
        } elseif (isset($_POST['booking_email_address']) && !empty($_POST['booking_email_address'])) {
            $user_email = sanitize_email($_POST['booking_email_address']);
        }

        if (isset($_POST['user_phone']) && !empty($_POST['user_phone'])) {
            $user_phone = sanitize_text_field($_POST['user_phone']);
        } elseif (isset($_POST['contact_phone_number']) && !empty($_POST['contact_phone_number'])) {
            $user_phone = sanitize_text_field($_POST['contact_phone_number']);
        }

        if (isset($_POST['travel_date']) && !empty($_POST['travel_date'])) {
            $travel_date = sanitize_text_field($_POST['travel_date']);
        } elseif (isset($_POST['travel_date_selection']) && !empty($_POST['travel_date_selection'])) {
            $travel_date = sanitize_text_field($_POST['travel_date_selection']);
        }

        // Basic validation
        if (empty($user_name) || empty($user_email) || !is_email($user_email)) {
            error_log('Passport Uploader: Validation failed - Name: ' . $user_name . ', Email: ' . $user_email);
            wp_die(__('Please provide a valid name and email address.', 'islandtime-passport'));
        }

        // Validate travel date
        if (empty($travel_date) || strtotime($travel_date) < strtotime('today')) {
            error_log('Passport Uploader: Invalid travel date: ' . $travel_date);
            wp_die(__('Please select a valid future travel date.', 'islandtime-passport'));
        }
        
        // Check for encryption key
        if (!defined('PASSPORT_ENCRYPTION_KEY')) {
            error_log('Passport Uploader: Encryption key not defined');
            wp_die(__('CRITICAL ERROR: Encryption key is not configured. Submission cannot be saved.', 'islandtime-passport'));
        }

        // 3. Handle Multiple File Uploads
if (empty($_FILES['passport_files']) || empty($_FILES['passport_files']['name'][0])) {
    error_log('Passport Uploader: No files uploaded');
    wp_die(__('Please select at least one passport file to upload.', 'islandtime-passport'));
}

$uploaded_files = $_FILES['passport_files'];
$file_count = count($uploaded_files['name']);
$saved_filenames = array();

// Process each uploaded file
for ($i = 0; $i < $file_count; $i++) {
    if ($uploaded_files['error'][$i] !== UPLOAD_ERR_OK) {
        error_log("Passport Uploader: File upload error for file {$i}: " . $uploaded_files['error'][$i]);
        continue; // Skip files with upload errors
    }

    // Enhanced file validation with better HEIC support
    $file_name = $uploaded_files['name'][$i];
    $file_tmp_name = $uploaded_files['tmp_name'][$i];
    $file_size = $uploaded_files['size'][$i];
    
    // Get file extension
    $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // Define allowed extensions
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'pdf', 'heic', 'heif');
    
    // Check file extension
    if (!in_array($file_extension, $allowed_extensions)) {
        error_log("Passport Uploader: Invalid file extension rejected: " . $file_name . " (extension: " . $file_extension . ")");
        wp_die(__('Invalid file type. Only JPG, PNG, PDF, and HEIC files are allowed. File: ' . $file_name, 'islandtime-passport'));
    }
    
    // Additional MIME type validation for extra security
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $file_mime_type = finfo_file($finfo, $file_tmp_name);
    finfo_close($finfo);
    
    $allowed_mime_types = array(
        'image/jpeg',
        'image/jpg', 
        'image/png',
        'application/pdf',
        'image/heic',
        'image/heif'
    );
    
    // Special handling for HEIC files - they might have different MIME types
    $is_heic_file = in_array($file_extension, array('heic', 'heif'));
    
    if (!$is_heic_file && !in_array($file_mime_type, $allowed_mime_types)) {
        error_log("Passport Uploader: Invalid MIME type rejected: " . $file_name . " (MIME: " . $file_mime_type . ")");
        wp_die(__('Invalid file type detected. Only JPG, PNG, PDF, and HEIC files are allowed. File: ' . $file_name, 'islandtime-passport'));
    }
    
    // For HEIC files, we're more lenient with MIME type checking since it varies
    if ($is_heic_file) {
        error_log("Passport Uploader: HEIC file accepted: " . $file_name . " (MIME: " . $file_mime_type . ", Extension: " . $file_extension . ")");
    }

    // Generate a unique, random filename
    $new_filename = wp_generate_password(16, false, false) . '_' . time() . '_' . $i . '.' . $file_extension;
    $new_filepath = PASSPORT_UPLOADER_UPLOAD_DIR . $new_filename;

    // Move the uploaded file to the secure directory
    if (move_uploaded_file($file_tmp_name, $new_filepath)) {
        $saved_filenames[] = $new_filename;
        error_log("Passport Uploader: File saved successfully: " . $new_filename . " (Original: " . $file_name . ")");
    } else {
        error_log("Passport Uploader: Failed to move uploaded file: " . $file_name);
        wp_die(__('Failed to save uploaded file: ' . $file_name, 'islandtime-passport'));
    }
}

        if (empty($saved_filenames)) {
            error_log("Passport Uploader: No files were successfully saved");
            wp_die(__('Failed to save any uploaded files.', 'islandtime-passport'));
        }

        // 4. Save to Database (WITH ENCRYPTION)
        $table_name = $wpdb->prefix . 'passport_submissions';
        
        // Encrypt data
        $encrypted_name = $this->encrypt_data($user_name);
        $encrypted_email = $this->encrypt_data($user_email);
        $encrypted_phone = $this->encrypt_data($user_phone);

        if ($encrypted_name === false || $encrypted_email === false || $encrypted_phone === false) {
            // Delete uploaded files
            foreach ($saved_filenames as $filename) {
                @unlink(PASSPORT_UPLOADER_UPLOAD_DIR . $filename);
            }
            error_log("Passport Uploader: Encryption failed for submission data");
            wp_die(__('Failed to encrypt submission data. Check key configuration.', 'islandtime-passport'));
        }

        // Store filenames as JSON array
        $file_path_json = json_encode($saved_filenames);

        $insert_result = $wpdb->insert(
            $table_name,
            array(
                'user_name' => $encrypted_name,
                'user_email' => $encrypted_email,
                'user_phone' => $encrypted_phone,
                'submission_date' => $travel_date,
                'file_path' => $file_path_json,
            ),
            array('%s', '%s', '%s', '%s', '%s')
        );

        if ($insert_result === false) {
            // If DB insert fails, DELETE the uploaded files
            foreach ($saved_filenames as $filename) {
                @unlink(PASSPORT_UPLOADER_UPLOAD_DIR . $filename);
            }
            error_log("Passport Uploader: Database insert failed: " . $wpdb->last_error);
            wp_die(__('Failed to save your submission to the database.', 'islandtime-passport'));
        }

        // 5. Send email notifications
        $submission_id = $wpdb->insert_id;
        if ($submission_id > 0) {
            // Send admin notifications
            $admin_emails_sent = $this->send_admin_email_notifications(
                $user_name, 
                $user_email, 
                $user_phone, 
                $travel_date, 
                count($saved_filenames), 
                $submission_id
            );
            
            // Send customer confirmation - NOW USES THE ENHANCED VERSION BELOW
            $customer_email_sent = $this->send_customer_confirmation_email(
                $user_name, 
                $user_email, 
                $user_phone, 
                $travel_date, 
                count($saved_filenames), 
                $submission_id
            );
            
            if ($admin_emails_sent === 0) {
                error_log("Passport Uploader: CRITICAL - No admin notification emails were sent for submission #{$submission_id}");
            }
            
            if (!$customer_email_sent) {
                error_log("Passport Uploader: WARNING - Customer confirmation email failed for submission #{$submission_id}");
            }
        }

        // 6. Redirect to thank you page
        $thank_you_page = 'https://islandtimebvi.com/thank-you-passport-submitted.html';
        error_log("Passport Uploader: Submission successful, redirecting to: " . $thank_you_page);
        wp_safe_redirect($thank_you_page);
        exit;
    }

    // =====================================================
    // ANTI-FOLLOW-UP EMAIL ENHANCEMENTS
    // =====================================================

    /**
     * Enhanced customer confirmation email with DO NOT REPLY warnings
     * (This replaces the original plain text version)
     */
    private function send_customer_confirmation_email($user_name, $user_email, $user_phone, $travel_date, $file_count, $submission_id) {
        $site_name = get_bloginfo('name');
        $submission_time = current_time('F j, Y g:i A');
        $contact_email = 'info@islandtimeltd.com';
        $water_taxi_email = 'watertaxi@islandtimeltd.com';
        $contact_page = home_url('/contact');
        
        $subject = "✅ Passport Information Received - Island Time BVI (DO NOT REPLY)";
        
        // HTML email with big warning box
        $message = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; }
                .warning-box { background: #fff3cd; border: 4px solid #ffc107; padding: 20px; margin: 20px 0; border-radius: 8px; text-align: center; }
                .warning-box h2 { color: #856404; margin: 0 0 10px 0; font-size: 24px; }
                .warning-box p { color: #856404; font-size: 16px; margin: 5px 0; font-weight: bold; }
                .info-box { background: #e6f7ff; border-left: 4px solid #00b0b9; padding: 15px; margin: 20px 0; }
                .success-box { background: #d4edda; border: 2px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 8px; }
                .contact-box { background: #f8f9fa; border: 2px solid #dee2e6; padding: 15px; margin: 20px 0; border-radius: 8px; }
                .footer { margin-top: 30px; padding-top: 20px; border-top: 2px solid #dee2e6; font-size: 12px; color: #6c757d; text-align: center; }
            </style>
        </head>
        <body>
            
            <div class='warning-box'>
                <h2>⚠️ IMPORTANT - PLEASE READ</h2>
                <p>DO NOT REPLY TO THIS EMAIL</p>
                <p style='font-size: 14px; font-weight: normal;'>This is an automated message. Replies are not monitored.</p>
            </div>
            
            <h2>Dear {$user_name},</h2>
            
            <p>Thank you for submitting your passport information to Island Time BVI! Your documents have been securely received.</p>
            
            <div class='success-box'>
                <h3 style='color: #155724; margin-top: 0;'>✅ Submission Confirmed</h3>
                <p><strong>Submission ID:</strong> #{$submission_id}</p>
                <p><strong>Travel Date:</strong> {$travel_date}</p>
                <p><strong>Files Uploaded:</strong> {$file_count}</p>
                <p><strong>Time:</strong> {$submission_time}</p>
            </div>
            
            <div class='info-box'>
                <h3 style='color: #0056b3; margin-top: 0;'>📋 What Happens Next</h3>
                <ul style='margin-bottom: 0;'>
                    <li>Our team will review your documents before your travel date</li>
                    <li>You'll receive an SMS reminder 24 hours before departure</li>
                    <li>No further action is needed from you</li>
                </ul>
            </div>
            
            <div class='contact-box'>
                <h3 style='color: #333; margin-top: 0;'>📞 Need Assistance?</h3>
                <p><strong>Please use these official channels (do not reply to this email):</strong></p>
                <ul style='list-style: none; padding-left: 0;'>
                    <li style='margin-bottom: 10px;'>📧 <strong>Email:</strong> <a href='mailto:{$contact_email}'>{$contact_email}</a></li>
                    <li style='margin-bottom: 10px;'>📱 <strong>Water Taxi Team:</strong> <a href='mailto:{$water_taxi_email}'>{$water_taxi_email}</a></li>
                    <li style='margin-bottom: 10px;'>🌐 <strong>Contact Form:</strong> <a href='{$contact_page}'>Click Here</a></li>
                    <li style='margin-bottom: 10px;'>📞 <strong>Phone:</strong> +1 (284) 222-1234</li>
                </ul>
            </div>
            
            <div style='background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 20px 0;'>
                <p style='margin: 0;'><strong>🌟 Good to know:</strong> You can check your submission status anytime at <a href='{$contact_page}'>our website</a> - no need to email us!</p>
            </div>
            
            <p>We look forward to welcoming you to the beautiful British Virgin Islands!</p>
            
            <p>Safe travels,<br>
            <strong>The Island Time BVI Team</strong></p>
            
            <div class='footer'>
                <p style='margin: 5px 0;'><strong>⚠️ This is an automated message. Please do not reply to this email.</strong></p>
                <p style='margin: 5px 0;'>Island Time BVI • www.islandtimebvi.com</p>
            </div>
            
        </body>
        </html>
        ";
        
        $headers = array(
            'From: Island Time BVI <no-reply@islandtimebvi.com>',
            'Reply-To: ' . $contact_email,
            'Content-Type: text/html; charset=UTF-8',
            'X-Auto-Response-Suppress: OOF, AutoReply, All',
            'Auto-Submitted: auto-generated',
            'Precedence: bulk',
            'X-Passport-Submission-ID: ' . $submission_id
        );
        
        $result = wp_mail($user_email, $subject, $message, $headers);
        
        if ($result) {
            error_log("Passport Uploader: Enhanced customer confirmation email sent successfully to {$user_email} for submission #{$submission_id}");
        } else {
            error_log("Passport Uploader: FAILED to send customer confirmation email to {$user_email} for submission #{$submission_id}");
        }
        
        return $result;
    }

    /**
     * Block auto-replies (Out of Office, etc.)
     */
    public function block_auto_replies($args) {
        // Check if this is an auto-reply
        if (isset($_SERVER['HTTP_AUTO_SUBMITTED']) || 
            isset($_SERVER['HTTP_X_AUTORESPONDER']) ||
            strpos($args['message'], 'Out of Office') !== false ||
            strpos($args['message'], 'out of the office') !== false ||
            strpos($args['message'], 'Automatic reply') !== false ||
            strpos($args['message'], 'auto-reply') !== false ||
            strpos($args['subject'], 'Out of Office') !== false ||
            strpos($args['subject'], 'Automatic reply') !== false) {
            
            error_log('Passport Uploader: Auto-reply blocked from: ' . $args['to']);
            return false; // Block the email
        }
        
        return $args;
    }

    /**
     * Add status check shortcode
     */
    public function passport_status_shortcode($atts) {
        ob_start();
        ?>
        <div style="max-width: 500px; margin: 50px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.1);">
            <h2 style="color: #00b0b9; margin-bottom: 20px;">Check Passport Status</h2>
            <p style="margin-bottom: 20px;">Enter your email to check your submission status (no need to email us!)</p>
            
            <form method="post" style="margin-bottom: 20px;">
                <input type="email" name="check_email" placeholder="Your email address" required 
                       style="width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 8px; margin-bottom: 15px;">
                <button type="submit" style="background: #00b0b9; color: white; border: none; padding: 12px 30px; border-radius: 8px; cursor: pointer; width: 100%; font-size: 16px;">
                    Check Status
                </button>
            </form>
            
            <?php
            if (isset($_POST['check_email'])) {
                $email = sanitize_email($_POST['check_email']);
                global $wpdb;
                $table_name = $wpdb->prefix . 'passport_submissions';
                
                $submission = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $table_name WHERE user_email = %s ORDER BY submission_time DESC LIMIT 1",
                    $email
                ));
                
                if ($submission) {
                    // Decrypt data
                    $decrypted_name = $this->decrypt_data($submission->user_name);
                    $file_count = count(json_decode($submission->file_path, true));
                    
                    echo '<div style="background: #c6f6d5; border: 2px solid #48bb78; color: #22543d; padding: 15px; border-radius: 8px; margin-top: 20px;">';
                    echo '<p><strong>✅ Status:</strong> Received</p>';
                    echo '<p><strong>📅 Submitted:</strong> ' . date('F j, Y', strtotime($submission->submission_time)) . '</p>';
                    echo '<p><strong>✈️ Travel Date:</strong> ' . date('F j, Y', strtotime($submission->submission_date)) . '</p>';
                    echo '<p><strong>📄 Files:</strong> ' . $file_count . ' uploaded</p>';
                    echo '<p style="margin-top: 10px; font-style: italic;">All good! No need to contact us.</p>';
                    echo '</div>';
                } else {
                    echo '<div style="background: #fed7d7; border: 2px solid #e53e3e; color: #742a2a; padding: 15px; border-radius: 8px; margin-top: 20px;">';
                    echo 'No submission found with this email. If you just submitted, please allow a few minutes for processing.';
                    echo '</div>';
                }
            }
            ?>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center;">
                <p style="color: #718096;">Need immediate help?</p>
                <p style="margin: 5px 0;"><strong>📞 Call us:</strong> +1 (284) 222-1234</p>
                <p style="margin: 5px 0;"><strong>🌐 Visit:</strong> <a href="/contact">Contact Page</a></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize the plugin
new PassportUploaderPlugin();